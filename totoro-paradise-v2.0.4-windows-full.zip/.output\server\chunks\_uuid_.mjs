import { d as defineEventHandler } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const _uuid_ = defineEventHandler(async (e) => {
  try {
    const scanResult = await $fetch(
      `https://long.open.weixin.qq.com/connect/l/qrconnect?uuid=${e.context.params.uuid}&f=url`
    );
    const reg = new RegExp(/:\/\/oauth\?code=(\w+)&/);
    const res = reg.exec(scanResult);
    if (res === null)
      throw new Error("no code");
    return { message: null, code: res[1] };
  } catch (e2) {
    console.log(e2);
    return {
      message: "\u626B\u7801\u5931\u8D25",
      code: null
    };
  }
});

export { _uuid_ as default };
//# sourceMappingURL=_uuid_.mjs.map
