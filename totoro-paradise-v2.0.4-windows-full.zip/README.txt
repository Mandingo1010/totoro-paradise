========================================
  Totoro Paradise v2.0.4
  Sunshine Running Assistant
  (Full Package with Dependencies)
========================================

QUICK START
-----------
1. Double-click "Start.bat"
2. Wait for browser to open automatically
3. Use the web interface at http://localhost:3000

REQUIREMENTS
------------
- Windows 10/11
- Node.js 18+ (Download from https://nodejs.org if not installed)

Note: This package includes all dependencies.
      You only need to install Node.js runtime.

FEATURES
--------
- Sun Run: Fixed route running simulation
- Free Run: Custom distance (0.5-20km) and speed (3-25km/h)
- Batch Run: 1-10 consecutive submissions with intervals
- Records: View and export running history

TROUBLESHOOTING
---------------
Q: "Node.js not found" error?
A: Install Node.js from https://nodejs.org (LTS version recommended)

Q: Browser doesn't open automatically?
A: Manually open browser and visit http://localhost:3000

Q: Port 3000 is already in use?
A: Close other programs using port 3000, or restart your computer

Q: How to stop the server?
A: Close the black command window

DISCLAIMER
----------
This tool is for educational and research purposes only.
Please comply with your school's regulations.
Use at your own risk.

GitHub: https://github.com/Mandingo1010/totoro-paradise
========================================