import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { T as TotoroApiWrapper } from './TotoroApiWrapper.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ky';

const sunRunPaper_post = defineEventHandler(async (e) => {
  const body = await readBody(e);
  try {
    const paper = await TotoroApiWrapper.getSunRunPaper(body);
    if (paper.ifHasRun === "0") {
      return {
        message: "\u767B\u5F55\u6210\u529F",
        paper
      };
    } else {
      return {
        message: "\u4F60\u5DF2\u7ECF\u8DD1\u8FC7\u4E86",
        paper: null
      };
    }
  } catch (error) {
    console.log(error);
    return {
      message: "\u9F99\u732B\u670D\u52A1\u5668\u9519\u8BEF",
      paper: null
    };
  }
});

export { sunRunPaper_post as default };
//# sourceMappingURL=sunRunPaper.post.mjs.map
