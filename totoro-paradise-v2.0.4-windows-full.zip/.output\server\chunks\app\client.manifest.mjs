const client_manifest = {
  "_RecordManager.ca1GFQzY.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "RecordManager.ca1GFQzY.js",
    "imports": [
      "_TotoroApiWrapper.0XBy6xIO.js"
    ]
  },
  "_TotoroApiWrapper.0XBy6xIO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TotoroApiWrapper.0XBy6xIO.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_encryptRequestContent.xR-4sd76.js"
    ]
  },
  "_VAlert.!~{00n}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VAlert.beCzk2dt.css",
    "src": "_VAlert.!~{00n}~.js"
  },
  "_VAlert.f4nwjx00.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VAlert.beCzk2dt.css"
    ],
    "file": "VAlert.f4nwjx00.js",
    "imports": [
      "_VDivider.2lRhVl23.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VAlert.beCzk2dt.css": {
    "file": "VAlert.beCzk2dt.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VDivider.!~{00h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VDivider.pqpGY8Br.css",
    "src": "_VDivider.!~{00h}~.js"
  },
  "_VDivider.2lRhVl23.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VDivider.pqpGY8Br.css"
    ],
    "file": "VDivider.2lRhVl23.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VDivider.pqpGY8Br.css": {
    "file": "VDivider.pqpGY8Br.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VInput.!~{00e}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VInput.NekKMduu.css",
    "src": "_VInput.!~{00e}~.js"
  },
  "_VInput.5wa94YJB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VInput.NekKMduu.css"
    ],
    "file": "VInput.5wa94YJB.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_forwardRefs.g5bhJaRn.js"
    ]
  },
  "VInput.NekKMduu.css": {
    "file": "VInput.NekKMduu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VOverlay.!~{00j}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VOverlay.Tf1YKMFJ.css",
    "src": "_VOverlay.!~{00j}~.js"
  },
  "_VOverlay.-_NW9wYK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VOverlay.Tf1YKMFJ.css"
    ],
    "file": "VOverlay.-_NW9wYK.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_forwardRefs.g5bhJaRn.js",
      "_VDivider.2lRhVl23.js"
    ]
  },
  "VOverlay.Tf1YKMFJ.css": {
    "file": "VOverlay.Tf1YKMFJ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VSelect.!~{00i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VSelect.Nw8eJEGy.css",
    "src": "_VSelect.!~{00i}~.js"
  },
  "_VSelect.oCiMzImV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VSelect.Nw8eJEGy.css"
    ],
    "file": "VSelect.oCiMzImV.js",
    "imports": [
      "_VInput.5wa94YJB.js",
      "_forwardRefs.g5bhJaRn.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_VOverlay.-_NW9wYK.js",
      "_VDivider.2lRhVl23.js"
    ]
  },
  "VSelect.Nw8eJEGy.css": {
    "file": "VSelect.Nw8eJEGy.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VSnackbar.!~{00k}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VSnackbar.v60mgd1F.css",
    "src": "_VSnackbar.!~{00k}~.js"
  },
  "_VSnackbar.5uFvyCqt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VSnackbar.v60mgd1F.css"
    ],
    "file": "VSnackbar.5uFvyCqt.js",
    "imports": [
      "_VOverlay.-_NW9wYK.js",
      "_VDivider.2lRhVl23.js",
      "_forwardRefs.g5bhJaRn.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VSnackbar.v60mgd1F.css": {
    "file": "VSnackbar.v60mgd1F.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_VTable.!~{00p}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "VTable.mC3fofcj.css",
    "src": "_VTable.!~{00p}~.js"
  },
  "_VTable.GviO9kPo.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "VTable.mC3fofcj.css"
    ],
    "file": "VTable.GviO9kPo.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "VTable.mC3fofcj.css": {
    "file": "VTable.mC3fofcj.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "__plugin-vue_export-helper.x3n3nnut.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.x3n3nnut.js"
  },
  "_encryptRequestContent.xR-4sd76.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "encryptRequestContent.xR-4sd76.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_forwardRefs.g5bhJaRn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forwardRefs.g5bhJaRn.js"
  },
  "_generateRoute.BPYILp3h.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "generateRoute.BPYILp3h.js",
    "imports": [
      "_TotoroApiWrapper.0XBy6xIO.js"
    ]
  },
  "_index.VSDRNFIG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.VSDRNFIG.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.Lux5FAmV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.Lux5FAmV.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "src": "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.eot"
  },
  "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "src": "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.ttf"
  },
  "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "src": "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff"
  },
  "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "src": "node_modules/.pnpm/@mdi+font@7.4.47/node_modules/@mdi/font/fonts/materialdesignicons-webfont.woff2"
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-404.SaR2Zalm.css"
    ],
    "file": "error-404.rK9_AyIe.js",
    "imports": [
      "_nuxt-link.Lux5FAmV.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.SaR2Zalm.css": {
    "file": "error-404.SaR2Zalm.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "error-500.2itWk7wX.css"
    ],
    "file": "error-500.Soef4Rf9.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.x3n3nnut.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.2itWk7wX.css": {
    "file": "error-500.2itWk7wX.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "materialdesignicons-webfont.kq_ClZaA.eot",
      "materialdesignicons-webfont.6eb_lmTU.woff2",
      "materialdesignicons-webfont.D15t_tsC.woff",
      "materialdesignicons-webfont.e5j8FT_3.ttf"
    ],
    "css": [
      "entry.4Tt4-w_V.css"
    ],
    "dynamicImports": [
      "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/.pnpm/@nuxt+ui-templates@1.3.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.FBlyVdi9.js",
    "isEntry": true,
    "src": "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js"
  },
  "entry.4Tt4-w_V.css": {
    "file": "entry.4Tt4-w_V.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "materialdesignicons-webfont.kq_ClZaA.eot": {
    "file": "materialdesignicons-webfont.kq_ClZaA.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "materialdesignicons-webfont.6eb_lmTU.woff2": {
    "file": "materialdesignicons-webfont.6eb_lmTU.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "materialdesignicons-webfont.D15t_tsC.woff": {
    "file": "materialdesignicons-webfont.D15t_tsC.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "materialdesignicons-webfont.e5j8FT_3.ttf": {
    "file": "materialdesignicons-webfont.e5j8FT_3.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "pages/decode.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "decode.-da3dKDC.css"
    ],
    "file": "decode.k1FZKRx7.js",
    "imports": [
      "_encryptRequestContent.xR-4sd76.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_VInput.5wa94YJB.js",
      "_forwardRefs.g5bhJaRn.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/decode.vue"
  },
  "decode.-da3dKDC.css": {
    "file": "decode.-da3dKDC.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/freerun.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "freerun.q14ACMwA.css"
    ],
    "file": "freerun.vsJ_erSI.js",
    "imports": [
      "_generateRoute.BPYILp3h.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_VDivider.2lRhVl23.js",
      "_VSelect.oCiMzImV.js",
      "_VOverlay.-_NW9wYK.js",
      "_VInput.5wa94YJB.js",
      "_forwardRefs.g5bhJaRn.js",
      "_VSnackbar.5uFvyCqt.js",
      "__plugin-vue_export-helper.x3n3nnut.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_index.VSDRNFIG.js",
      "_VAlert.f4nwjx00.js",
      "_encryptRequestContent.xR-4sd76.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/freerun.vue"
  },
  "freerun.q14ACMwA.css": {
    "file": "freerun.q14ACMwA.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.L8nzHKUe.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_VDivider.2lRhVl23.js",
      "_encryptRequestContent.xR-4sd76.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/records.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "records.NvUszzCm.css"
    ],
    "file": "records.oXqcrYYe.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_RecordManager.ca1GFQzY.js",
      "_VDivider.2lRhVl23.js",
      "_forwardRefs.g5bhJaRn.js",
      "_VOverlay.-_NW9wYK.js",
      "_VSelect.oCiMzImV.js",
      "_VTable.GviO9kPo.js",
      "_VSnackbar.5uFvyCqt.js",
      "__plugin-vue_export-helper.x3n3nnut.js",
      "_encryptRequestContent.xR-4sd76.js",
      "_VInput.5wa94YJB.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/records.vue"
  },
  "records.NvUszzCm.css": {
    "file": "records.NvUszzCm.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/records/free/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "_id_.hlSt30bJ.css"
    ],
    "file": "_id_.Bq4p76Np.js",
    "imports": [
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_RecordManager.ca1GFQzY.js",
      "_VDivider.2lRhVl23.js",
      "_VSnackbar.5uFvyCqt.js",
      "_VOverlay.-_NW9wYK.js",
      "__plugin-vue_export-helper.x3n3nnut.js",
      "_encryptRequestContent.xR-4sd76.js",
      "_forwardRefs.g5bhJaRn.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/records/free/[id].vue"
  },
  "_id_.hlSt30bJ.css": {
    "file": "_id_.hlSt30bJ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/run/[route].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_route_.Wrq7Am2A.js",
    "imports": [
      "_generateRoute.BPYILp3h.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_index.VSDRNFIG.js",
      "_encryptRequestContent.xR-4sd76.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/run/[route].vue"
  },
  "pages/scanned.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scanned._gQx0u2y.js",
    "imports": [
      "_nuxt-link.Lux5FAmV.js",
      "node_modules/.pnpm/nuxt@3.9.1_eslint@8.57.0_typescript@5.3.3_vite@5.0.11/node_modules/nuxt/dist/app/entry.js",
      "_generateRoute.BPYILp3h.js",
      "_TotoroApiWrapper.0XBy6xIO.js",
      "_VAlert.f4nwjx00.js",
      "_VTable.GviO9kPo.js",
      "_VDivider.2lRhVl23.js",
      "_VSelect.oCiMzImV.js",
      "_VOverlay.-_NW9wYK.js",
      "_encryptRequestContent.xR-4sd76.js",
      "_VInput.5wa94YJB.js",
      "_forwardRefs.g5bhJaRn.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/scanned.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
