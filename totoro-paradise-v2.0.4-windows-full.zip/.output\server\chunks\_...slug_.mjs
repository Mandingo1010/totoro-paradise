import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';

const ____slug_ = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    // "Content-Length": "0",
    Host: "app.xtotoro.com",
    Connection: "keep-alive",
    "Accept-Encoding": "gzip, deflate, br",
    "User-Agent": "TotoroSchool/1.2.14 (iPhone; iOS 17.4.1; Scale/3.00)",
    Cookie: event.node.req.headers.cookie,
    Accept: "application/json"
    // 'sec-fetch-mode': undefined,
  };
  const path = event.path.replace("/api/totoro/", "/app/");
  return fetch(`https://app.xtotoro.com${path}`, {
    method: "post",
    headers: { ...headers },
    body
  });
});

export { ____slug_ as default };
//# sourceMappingURL=_...slug_.mjs.map
