import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { T as TotoroApiWrapper } from './TotoroApiWrapper.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ky';

const getRunBegin_post = defineEventHandler(async (e) => {
  try {
    const body = await readBody(e);
    const res = await TotoroApiWrapper.getRunBegin(body);
    return res;
  } catch (e2) {
    return { message: e2.message };
  }
});

export { getRunBegin_post as default };
//# sourceMappingURL=getRunBegin.post.mjs.map
