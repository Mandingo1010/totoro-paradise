import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { T as TotoroApiWrapper } from './TotoroApiWrapper.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'ky';

const sunRunExercisesDetail_post = defineEventHandler(async (e) => {
  try {
    const body = await readBody(
      e
    );
    const res = await TotoroApiWrapper.sunRunExercisesDetail(body);
    return res;
  } catch (e2) {
    return { message: e2.message };
  }
});

export { sunRunExercisesDetail_post as default };
//# sourceMappingURL=sunRunExercisesDetail.post.mjs.map
