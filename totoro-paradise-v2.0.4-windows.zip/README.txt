========================================
  Totoro Paradise v2.0.4
  Sunshine Running Assistant
========================================

QUICK START
-----------
1. Double-click "Start.bat"
2. Wait for browser to open
3. Use the web interface

REQUIREMENTS
------------
- Windows 10/11
- Node.js 16+ (Download from https://nodejs.org)

FEATURES
--------
- Sun Run: Fixed route running simulation
- Free Run: Custom distance and speed (0.5-20km, 3-25km/h)
- Batch Run: 1-10 consecutive submissions
- Records: View and export running history

TROUBLESHOOTING
---------------
Q: "Node.js not found" error?
A: Install Node.js from https://nodejs.org (LTS version)

Q: Browser doesn't open?
A: Manually visit http://localhost:3000

Q: How to stop?
A: Close the command window

DISCLAIMER
----------
This tool is for educational purposes only.
Please comply with school regulations.

GitHub: https://github.com/Mandingo1010/totoro-paradise
========================================